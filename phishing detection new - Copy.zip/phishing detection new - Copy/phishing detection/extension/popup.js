document.addEventListener('DOMContentLoaded', function() {
  
  // Cache DOM Elements
  const urlDisplay = document.getElementById('url-display');
  const resultUrlBox = document.getElementById('url-result');
  const analyzeUrlBtn = document.getElementById('analyze-url-btn');

  const emailInput = document.getElementById('email-input');
  const resultEmailBox = document.getElementById('email-result');
  const analyzeEmailBtn = document.getElementById('analyze-email-btn');

  const dashBtn = document.getElementById('open-dashboard');
  
  let currentUrl = "";

  // 1. EXTRACT URL ON OPEN
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    if (chrome.runtime.lastError) {
      urlDisplay.textContent = "Error: " + chrome.runtime.lastError.message;
      return;
    }
    if (tabs && tabs.length > 0 && tabs[0].url) {
      currentUrl = tabs[0].url;
      urlDisplay.textContent = currentUrl;
      // Auto-scan url upon opening
      scanUrl(currentUrl);
    } else {
      urlDisplay.textContent = "URL access blocked on this specific page.";
    }
  });

  // 2. DOMAIN SCANNER LOGIC
  async function scanUrl(domain) {
    if (!domain || domain.startsWith('chrome://') || domain.startsWith('edge://')) {
      resultUrlBox.textContent = "Cannot analyze browser-internal pages.";
      resultUrlBox.className = "result-box";
      return;
    }

    resultUrlBox.textContent = "Analyzing domain structure...";
    resultUrlBox.style.color = "#4299e1";

    try {
      const response = await fetch('http://localhost:5050/analyze/url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: domain })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);

      if (data.prediction === "Safe") {
        resultUrlBox.textContent = `Safe Domain (${data.confidence}% Confidence)`;
        resultUrlBox.className = "result-box safe";
      } else {
        resultUrlBox.textContent = `Phishing Domain! (${data.confidence}% Confidence)`;
        resultUrlBox.className = "result-box phishing";
      }
    } catch (e) {
      resultUrlBox.textContent = "Backend Offline.";
      resultUrlBox.className = "result-box";
      resultUrlBox.style.color = "red";
    }
  }

  analyzeUrlBtn.addEventListener('click', () => scanUrl(currentUrl));

  // 3. EMAIL SCANNER LOGIC
  analyzeEmailBtn.addEventListener('click', async function() {
    const rawText = emailInput.value.trim();
    if (!rawText) {
      resultEmailBox.textContent = "Please paste email text first.";
      resultEmailBox.className = "result-box";
      return;
    }

    resultEmailBox.textContent = "Vectorizing text (TF-IDF)...";
    resultEmailBox.className = "result-box";

    try {
      const response = await fetch('http://localhost:5050/analyze/email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: rawText })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);

      if (data.prediction === "Safe") {
        resultEmailBox.textContent = `Safe Email (${data.confidence}% NLP Confidence)`;
        resultEmailBox.className = "result-box safe";
      } else {
        resultEmailBox.textContent = `Phishing Email! (${data.confidence}% NLP Confidence)`;
        resultEmailBox.className = "result-box phishing";
      }
    } catch (e) {
      resultEmailBox.textContent = "Backend Offline.";
      resultEmailBox.className = "result-box";
      resultEmailBox.style.color = "red";
    }
  });

  // 4. OPEN DASHBOARD
  dashBtn.addEventListener('click', () => window.open('http://localhost:5050/dashboard', '_blank'));
});
