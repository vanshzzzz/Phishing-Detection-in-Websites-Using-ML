// PhishGuard Active Content Injection
// This script runs silently on EVERY webpage the user navigates to.

(async function scanCurrentPage() {
    // 1. Immediately extract the URL natively from the browser DOM
    const targetUrl = window.location.href;

    // We do not want to scan the user's local chrome extensions or localhost dashboards
    if (
        targetUrl.startsWith('chrome://') ||
        targetUrl.includes('localhost:5050') ||
        targetUrl.includes('127.0.0.1:5050')
    ) {
        return;
    }

    try {
        // 2. Transmit the URL to our Flask active background ML engine
        const response = await fetch('http://localhost:5050/analyze/url', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url: targetUrl })
        });

        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.error || 'URL analysis request failed');
        }

        // 3. Actively intercept the screen whenever model predicts phishing.
        if (data.prediction === 'Phishing') {
            triggerPhishingOverlay(data.confidence);
        }

    } catch (e) {
        console.error("PhishGuard backend scan failed:", e);
    }
})();

function triggerPhishingOverlay(confidenceScore) {
    if (document.getElementById('phishguard-active-threat-overlay')) {
        return;
    }

    // To ensure the user CANNOT interact with the malicious phishing DOM,
    // we generate a massive maximum z-index glassmorphism overlay.
    
    const overlay = document.createElement('div');
    overlay.id = "phishguard-active-threat-overlay";
    
    // Using explicit inline styles ensures the phishing site CSS cannot override our blocker.
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100vw';
    overlay.style.height = '100vh';
    overlay.style.backgroundColor = 'rgba(220, 38, 38, 0.95)'; // Deep red blur
    overlay.style.backdropFilter = 'blur(12px)';
    overlay.style.zIndex = '2147483647'; // Maximum possible CSS Z-Index
    overlay.style.display = 'flex';
    overlay.style.flexDirection = 'column';
    overlay.style.justifyContent = 'center';
    overlay.style.alignItems = 'center';
    overlay.style.color = 'white';
    overlay.style.fontFamily = "'Segoe UI', Roboto, sans-serif";
    overlay.style.padding = '40px';
    overlay.style.textAlign = 'center';

    // Build the Threat Text Payload
    overlay.innerHTML = `
        <div style="background: white; padding: 40px; border-radius: 12px; max-width: 600px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);">
            <svg style="width: 80px; height: 80px; color: #dc2626; margin: 0 auto 20px auto;" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 1.944A11.954 11.954 0 012.166 5C2.056 5.649 2 6.319 2 7c0 5.225 3.34 9.67 8 11.317C14.66 16.67 18 12.225 18 7c0-.682-.057-1.35-.166-2.001A11.954 11.954 0 0110 1.944zM11 14a1 1 0 11-2 0 1 1 0 012 0zm0-7a1 1 0 10-2 0v3a1 1 0 102 0V7z" clip-rule="evenodd"></path>
            </svg>
            <h1 style="color: #991b1b; font-size: 32px; font-weight: 800; margin: 0 0 10px 0;">Critical Threat Blocked</h1>
            <p style="color: #4b5563; font-size: 18px; line-height: 1.5; margin: 0 0 20px 0;">
                PhishGuard Machine Learning has actively detected that this domain is a Phishing attack. 
                <br><b>Confidence Score: ${confidenceScore}%</b>
            </p>
            <p style="color: #6b7280; font-size: 14px;">Do not enter passwords, emails, or credit card information.</p>
            
            <button id="phishguard-bypass-btn" style="margin-top: 30px; background: transparent; border: 1px solid #d1d5db; color: #6b7280; padding: 10px 20px; border-radius: 6px; cursor: pointer; transition: all 0.2s;">
                I understand the risk (Bypass)
            </button>
        </div>
    `;

    // Append forcibly to the HTML body
    const mountTarget = document.body || document.documentElement;
    if (!mountTarget) return;
    mountTarget.appendChild(overlay);

    // Bypass logic (hides the overlay for the session)
    document.getElementById('phishguard-bypass-btn').addEventListener('click', () => {
        overlay.style.display = 'none';
    });
}
