from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import joblib
import sqlite3
import pandas as pd
from datetime import datetime
import os
import sys
import logging
import ipaddress
import re
from functools import lru_cache
import importlib.util

try:
    import sklearn
except Exception:
    sklearn = None

try:
    import xgboost as xgb
except Exception:
    xgb = None

app = Flask(__name__)
# Enable Cross-Origin Resource Sharing (CORS) for the Extension popup and content scripts
CORS(app)
# Reduce noisy Flask request logs so URL safety lines are easy to read.
logging.getLogger("werkzeug").setLevel(logging.WARNING)

# -------------------------------------------------------------
# DATABASE SETUP (FOR DASHBOARD)
# -------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.path.join(BASE_DIR, 'phishing_logs.db')

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    # We store type ('url' or 'email') so the dashboard can differentiate threats
    c.execute('''
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_type TEXT NOT NULL,
            payload TEXT NOT NULL,
            prediction TEXT NOT NULL,
            confidence REAL NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

init_db()

def get_db_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def print_runtime_info():
    sklearn_version = sklearn.__version__ if sklearn is not None else "not installed"
    print(f"Runtime: Python {sys.version.split()[0]}, scikit-learn {sklearn_version}")

# -------------------------------------------------------------
# LOAD THE MULTI-MODAL MACHINE LEARNING MODELS
# -------------------------------------------------------------
URL_MODEL_CANDIDATES = [
    os.path.join(BASE_DIR, "model", "xgb_model.json"),
    os.path.join(BASE_DIR, "phishing-model-bundle", "newmodel.pkl"),
    os.path.join(BASE_DIR, "model", "best_phishing_model.joblib"),
    os.path.join(BASE_DIR, "model", "newmodel.pkl"),
    os.path.join(BASE_DIR, "artifacts", "phishing_model.joblib"),
    os.path.join(BASE_DIR, "url_phishing_model_v4.pkl"),
]

url_model = None
url_model_kind = None
model_load_errors = []
print_runtime_info()
for model_path in URL_MODEL_CANDIDATES:
    if not os.path.exists(model_path):
        continue
    try:
        if model_path.endswith(".json"):
            if xgb is None:
                raise RuntimeError("xgboost is not installed in current runtime")
            model = xgb.XGBClassifier()
            model.load_model(model_path)
            url_model = model
            url_model_kind = "xgboost_json"
        else:
            url_model = joblib.load(model_path)
            url_model_kind = "joblib_pickle"
        print(f"URL Model '{model_path}' loaded successfully.")
        break
    except Exception as e:
        model_load_errors.append(f"{model_path}: {e}")

if url_model is None:
    if model_load_errors:
        print("Error loading URL model. Tried candidates:\n" + "\n".join(model_load_errors))
        print("Hint: model may be from a different sklearn version. Re-export the model in this runtime or run with the original training environment.")
    else:
        print(f"Error loading URL model: none of these files exist: {URL_MODEL_CANDIDATES}")

try:
    email_model = joblib.load(os.path.join(BASE_DIR, "model_email", "email_model_v1.pkl"))
    email_vectorizer = joblib.load(os.path.join(BASE_DIR, "model_email", "tfidf_vectorizer_v1.pkl"))
    print("Email Models loaded successfully.")
except Exception as e:
    email_model = None
    email_vectorizer = None
    print(f"Email models unavailable: {e}")

# -------------------------------------------------------------
# URL FEATURE EXTRACTION (Matches the 25MB dataset structure)
# -------------------------------------------------------------
def extract_url_features(url):
    parsed = urllib.parse.urlparse(url)
    domain = normalize_domain(url)
    directory = parsed.path or ""
    file_part = directory.split("/")[-1] if directory else ""
    params = parsed.query or ""

    features = {}

    symbol_map = {
        "dot": ".",
        "hyphen": "-",
        "underline": "_",
        "slash": "/",
        "questionmark": "?",
        "equal": "=",
        "at": "@",
        "and": "&",
        "exclamation": "!",
        "space": " ",
        "tilde": "~",
        "comma": ",",
        "plus": "+",
        "asterisk": "*",
        "hashtag": "#",
        "dollar": "$",
        "percent": "%",
    }

    section_values = {
        "url": url,
        "domain": domain,
        "directory": directory,
        "file": file_part,
        "params": params,
    }

    for section, text in section_values.items():
        for token, symbol in symbol_map.items():
            features[f"qty_{token}_{section}"] = text.count(symbol)

    features["qty_vowels_domain"] = sum(ch in "aeiou" for ch in domain)
    features["length_url"] = len(url)
    features["domain_length"] = len(domain)
    features["directory_length"] = len(directory)
    features["file_length"] = len(file_part)
    features["params_length"] = len(params)
    features["qty_tld_url"] = domain.count(".")
    features["qty_params"] = 0 if not params else params.count("&") + 1
    features["tld_present_params"] = int(any(tld in params.lower() for tld in (".com", ".net", ".org", ".in")))
    features["email_in_url"] = int("@" in url)
    features["server_client_domain"] = int(("server" in domain) or ("client" in domain))
    features["url_shortened"] = int(any(s in domain for s in ("bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly")))

    try:
        ipaddress.ip_address(domain)
        features["domain_in_ip"] = 1
    except ValueError:
        features["domain_in_ip"] = 0

    # External/network features unavailable at runtime in this app; keep neutral defaults.
    default_zero_features = [
        "time_response",
        "domain_spf",
        "asn_ip",
        "time_domain_activation",
        "time_domain_expiration",
        "qty_ip_resolved",
        "qty_nameservers",
        "qty_mx_servers",
        "ttl_hostname",
        "tls_ssl_certificate",
        "qty_redirects",
        "url_google_index",
        "domain_google_index",
    ]
    for key in default_zero_features:
        features[key] = 0

    return features

def extract_xgb_fallback_features(url):
    """Dependency-free fallback feature set for xgb_model.json."""
    parsed = urllib.parse.urlparse(url)
    domain = normalize_domain(url)
    tld = domain.split(".")[-1] if "." in domain else ""

    letters = sum(ch.isalpha() for ch in url)
    digits = sum(ch.isdigit() for ch in url)
    ratio = letters / (digits + 1e-5)

    abnormal_patterns = ("@", "//", ".exe", ".zip", ".rar", ".dll", ".js")
    abnormal = int(any(p in url.lower() for p in abnormal_patterns))

    return {
        "URLLength": len(url),
        "DomainLength": len(domain),
        "TLDLength": len(tld),
        "NoOfImage": 0,
        "NoOfJS": 0,
        "NoOfCSS": 0,
        "NoOfSelfRef": 0,
        "NoOfExternalRef": 0,
        "IsHTTPS": int(parsed.scheme == "https"),
        "HasObfuscation": 0,
        "HasTitle": 0,
        "HasDescription": 0,
        "HasSubmitButton": 0,
        "HasSocialNet": 0,
        "HasFavicon": 0,
        "HasCopyrightInfo": 0,
        "popUpWindow": 0,
        "Iframe": 0,
        "Abnormal_URL": abnormal,
        "LetterToDigitRatio": ratio,
        "Redirect_0": 1,
        "Redirect_1": 0,
    }

import urllib.parse

# -------------------------------------------------------------
# HIGH-TRUST DOMAIN WHITELIST
# -------------------------------------------------------------
# Prevents false positives caused by dataset imbalance. The Safe dataset
# mostly contained apex domains without parameters, meaning any long URL
# is currently heavily penalized by the ML model.
SAFE_DOMAINS = {
    'google.com', 'www.google.com',
    'youtube.com', 'www.youtube.com',
    'facebook.com', 'www.facebook.com',
    'github.com', 'www.github.com',
    'microsoft.com', 'www.microsoft.com',
    'apple.com', 'www.apple.com',
    'reddit.com', 'www.reddit.com',
    'amazon.com', 'www.amazon.com',
    'amazon.in', 'www.amazon.in',
    'leetcode.com', 'www.leetcode.com',
    'netflix.com', 'www.netflix.com',
    'twitter.com', 'x.com', 'www.twitter.com',
    'hotstar.com', 'www.hotstar.com'
}

BLACKLISTED_DOMAINS = {
    "www.amtso.org",
}

SHORTENER_DOMAINS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "rb.gy", "is.gd", "cutt.ly", "rebrand.ly"
}

PHISHING_KEYWORDS = {
    "login", "signin", "verify", "verification", "secure", "security",
    "account", "password", "update", "confirm", "session", "support",
    "billing", "invoice", "alert", "checkpoint",
}

SUSPICIOUS_TLDS = {
    "tk", "ml", "ga", "cf", "gq", "xyz", "top", "click", "country", "kim",
    "info", "support", "rest", "loan", "men", "work", "biz", "icu", "online", "site"
}

POPULAR_BRANDS = {
    "paypal", "amazon", "apple", "microsoft", "google", "facebook", "instagram",
    "netflix", "bankofamerica", "wellsfargo", "chase", "linkedin", "ebay", "outlook"
}

def normalize_domain(url):
    parsed = urllib.parse.urlparse(url)
    raw_domain = parsed.netloc if parsed.netloc else parsed.path.split('/')[0]
    # Normalize casing/ports/trailing dot for stable whitelist checks.
    return raw_domain.lower().split(':')[0].rstrip('.')

def lexical_phish_score(url):
    """URL-only risk score (0-100). No network, no HTML, robust to fetch failures."""
    try:
        parsed = urllib.parse.urlparse(url)
    except Exception:
        return 0.0

    domain = normalize_domain(url)
    if not domain:
        return 0.0

    score = 0.0

    if len(url) > 75:
        score += 8
    if len(url) > 120:
        score += 8

    dot_count = domain.count(".")
    if dot_count >= 3:
        score += 8
    if dot_count >= 5:
        score += 8

    hyphen_count = domain.count("-")
    if hyphen_count >= 1:
        score += 6
    if hyphen_count >= 3:
        score += 8

    digits_in_domain = sum(ch.isdigit() for ch in domain)
    if domain and digits_in_domain / max(len(domain), 1) > 0.2:
        score += 8

    tld = domain.rsplit(".", 1)[-1] if "." in domain else ""
    if tld in SUSPICIOUS_TLDS:
        score += 14

    parts = domain.split(".")
    base_domain = ".".join(parts[-2:]) if len(parts) >= 2 else domain
    base_root = parts[-2] if len(parts) >= 2 else domain
    brand_in_url = None
    for brand in POPULAR_BRANDS:
        if brand in url.lower():
            brand_in_url = brand
            break
    if brand_in_url is not None:
        # Genuine brand domains (e.g. linkedin.com / linkedin.in) are exact base_root match.
        if base_root != brand_in_url:
            score += 28
            # Brand impersonation in a hyphenated or suspicious-TLD domain is strongly malicious.
            if hyphen_count >= 1 or tld in SUSPICIOUS_TLDS:
                score += 12

    keyword_hits = sum(1 for k in PHISHING_KEYWORDS if k in url.lower())
    if keyword_hits >= 1:
        score += 12
    if keyword_hits >= 2:
        score += 14
    if keyword_hits >= 3:
        score += 14

    if parsed.scheme == "http" and keyword_hits >= 1:
        score += 8

    query = (parsed.query or "").lower()
    query_keyword_hits = sum(1 for k in PHISHING_KEYWORDS if k in query)
    if query_keyword_hits >= 2:
        score += 20
    if "urgent" in query or "alert" in query or "limited" in query:
        score += 12

    if "@" in url or "%40" in url.lower():
        score += 25

    if url.count("/") > 6:
        score += 6

    try:
        ipaddress.ip_address(domain)
        score += 30
    except ValueError:
        pass

    return min(score, 100.0)

def classify_url_rules(url):
    """Hard phishing heuristics independent of ML model."""
    lower_url = url.lower()
    domain = normalize_domain(url)

    # Official Google Safe Browsing test pages should always be treated as unsafe.
    if domain == "testsafebrowsing.appspot.com" and any(
        token in lower_url for token in ("/s/phishing", "/s/malware", "/s/unwanted")
    ):
        return "Phishing", 100.0

    if domain in SHORTENER_DOMAINS:
        return "Phishing", 95.0

    if "@" in lower_url or "%40" in lower_url:
        return "Phishing", 98.0

    try:
        ipaddress.ip_address(domain)
        return "Phishing", 99.0
    except ValueError:
        pass

    has_keyword = any(k in lower_url for k in PHISHING_KEYWORDS)
    has_suspicious_shape = ("--" in domain) or (len(url) > 140) or (url.count("/") > 6)
    if has_keyword and has_suspicious_shape:
        return "Phishing", 90.0

    if lower_url.startswith("http://") and has_keyword:
        return "Phishing", 88.0

    return None

@lru_cache(maxsize=5000)
def classify_url_model(url):
    """Model-only URL classification with caching."""
    if url_model_kind == "xgboost_json":
        feature_values = None
        try:
            extractor_path = os.path.join(BASE_DIR, "model", "url_feature_extractor.py")
            spec = importlib.util.spec_from_file_location("url_feature_extractor", extractor_path)
            if spec is not None and spec.loader is not None:
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                feature_values = module.URLFeatureExtractor(url).extract_model_features()
                if isinstance(feature_values, dict) and "error" in feature_values:
                    feature_values = None
        except Exception:
            feature_values = None

        if feature_values is None:
            feature_values = extract_xgb_fallback_features(url)

        features = pd.DataFrame([feature_values])
    else:
        feature_values = extract_url_features(url)
        expected_cols = list(getattr(url_model, "feature_names_in_", []))
        if expected_cols:
            feature_values = {name: feature_values.get(name, 0) for name in expected_cols}
            features = pd.DataFrame([feature_values], columns=expected_cols)
        else:
            features = pd.DataFrame([feature_values])
    predicted_class = url_model.predict(features)[0]
    probabilities = url_model.predict_proba(features)[0]
    classes = list(url_model.classes_)
    pred_idx = classes.index(predicted_class)

    predicted_class_str = str(predicted_class).strip().lower()
    # Handle common encodings:
    # - {-1, 1}: -1 phishing, 1 safe
    # - {0, 1}: 1 phishing, 0 safe
    if set(classes) == {-1, 1}:
        is_phishing = int(predicted_class) == -1
    elif set(classes) == {0, 1}:
        is_phishing = int(predicted_class) == 1
    else:
        is_phishing = predicted_class_str in {"1", "-1", "phishing", "unsafe", "malicious"}

    result_label = "Phishing" if is_phishing else "Safe"
    confidence = round(float(probabilities[pred_idx]) * 100, 2)
    return result_label, confidence

PHISH_DECISION_THRESHOLD = 55.0

def classify_url(url):
    """Hard rules → ML model + lexical score ensemble for robust prediction."""
    domain = normalize_domain(url)

    if domain in BLACKLISTED_DOMAINS or domain.endswith(".amtso.org"):
        return "Phishing", 100.0

    if (
        domain in SAFE_DOMAINS
        or domain.endswith('.google.com')
        or domain.endswith('.amazon.in')
        or domain.endswith('.amazon.com')
    ):
        return "Safe", 100.0

    rule_result = classify_url_rules(url)
    if rule_result is not None:
        return rule_result

    lex_score = lexical_phish_score(url)

    try:
        model_label, model_confidence = classify_url_model(url)
    except Exception:
        model_label, model_confidence = "Safe", 50.0

    model_phish_prob = model_confidence if model_label == "Phishing" else (100.0 - model_confidence)

    # Weighted ensemble: model 70% + lexical 30%, then take max with lexical for safety.
    combined_phish = max(0.7 * model_phish_prob + 0.3 * lex_score, lex_score)

    if combined_phish >= PHISH_DECISION_THRESHOLD:
        return "Phishing", round(min(combined_phish, 100.0), 2)
    return "Safe", round(100.0 - combined_phish, 2)

# ANSI color codes for terminal output
GREEN = "\033[92m"
RED   = "\033[91m"
CYAN  = "\033[96m"
BOLD  = "\033[1m"
RESET = "\033[0m"

def log_url_check(url, safety_tag, confidence):
    """Color-coded terminal logging: green=SAFE, red=UNSAFE."""
    timestamp = datetime.now().strftime("%H:%M:%S")
    if safety_tag == "safe":
        tag = f"{GREEN}{BOLD}✔ SAFE  {RESET}"
    else:
        tag = f"{RED}{BOLD}✘ UNSAFE{RESET}"
    log_line = f"[{timestamp}] {tag} ({confidence:.2f}%) {url}"
    try:
        sys.stdout.write(log_line + "\n")
        sys.stdout.flush()
    except Exception:
        pass

def log_url_seen(url):
    """Log every incoming URL scan request."""
    timestamp = datetime.now().strftime("%H:%M:%S")
    try:
        sys.stdout.write(f"[{timestamp}] {CYAN}→ SCAN{RESET}   {url}\n")
        sys.stdout.flush()
    except Exception:
        pass

# -------------------------------------------------------------
# /ANALYZE/URL POST ENDPOINT (Triggered by Content Script & Popup)
# -------------------------------------------------------------
@app.route('/analyze/url', methods=['POST'])
def analyze_url():
    if url_model is None:
        return jsonify({"error": "URL model is unavailable or incompatible with current sklearn runtime. Please provide a compatible model artifact."}), 503

    data = request.get_json()
    if not data or 'url' not in data:
        return jsonify({"error": "Invalid input, 'url' field is required"}), 400
    
    url = data['url']
    log_url_seen(url)

    try:
        result_label, confidence = classify_url(url)

        conn = get_db_connection()
        conn.execute(
            'INSERT INTO scans (scan_type, payload, prediction, confidence, timestamp) VALUES (?, ?, ?, ?, ?)',
            ('url', url, result_label, confidence, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        )
        conn.commit()
        conn.close()

        safety_tag = "safe" if result_label == "Safe" else "unsafe"
        log_url_check(url, safety_tag, confidence)

        return jsonify({
            "url": url,
            "prediction": result_label,
            "confidence": confidence
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -------------------------------------------------------------
# /ANALYZE/EMAIL POST ENDPOINT (Triggered by Popup for Text Checks)
# -------------------------------------------------------------
@app.route('/analyze/email', methods=['POST'])
def analyze_email():
    if email_model is None or email_vectorizer is None:
        return jsonify({"error": "Email model files not found. Add 'email_model_v1.pkl' and 'tfidf_vectorizer_v1.pkl' to enable email scanning."}), 503

    data = request.get_json()
    if not data or 'text' not in data:
        return jsonify({"error": "Invalid input, 'text' field is required"}), 400
    
    text = data['text']

    try:
        # Convert the raw text directly into TF-IDF frequencies using the saved vocabulary
        vectorized_text = email_vectorizer.transform([text])
        prediction = email_model.predict(vectorized_text)[0]
        probabilities = email_model.predict_proba(vectorized_text)[0]
        
        result_label = "Phishing" if prediction == 1 else "Safe"
        confidence = round(probabilities[prediction] * 100, 2)

        # Truncate payload for the DB so giant emails don't lag the dashboard
        preview = text[:100] + "..." if len(text) > 100 else text

        conn = get_db_connection()
        conn.execute(
            'INSERT INTO scans (scan_type, payload, prediction, confidence, timestamp) VALUES (?, ?, ?, ?, ?)',
            ('email', preview, result_label, confidence, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        )
        conn.commit()
        conn.close()

        return jsonify({
            "text_preview": preview,
            "prediction": result_label,
            "confidence": confidence
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -------------------------------------------------------------
# /DASHBOARD GET ENDPOINT (ANALYTICS)
# -------------------------------------------------------------
@app.route('/dashboard', methods=['GET'])
def dashboard():
    """ Render an HTML dashboard containing statistics about BOTH intercepted URLs and Emails. """
    conn = get_db_connection() 
    
    total_scans = conn.execute('SELECT COUNT(*) FROM scans').fetchone()[0]
    safe_count = conn.execute('SELECT COUNT(*) FROM scans WHERE prediction = "Safe"').fetchone()[0]
    phishing_count = conn.execute('SELECT COUNT(*) FROM scans WHERE prediction = "Phishing"').fetchone()[0]
    
    url_scans = conn.execute('SELECT COUNT(*) FROM scans WHERE scan_type = "url"').fetchone()[0]
    email_scans = conn.execute('SELECT COUNT(*) FROM scans WHERE scan_type = "email"').fetchone()[0]

    recent_scans = conn.execute('SELECT * FROM scans ORDER BY timestamp DESC LIMIT 20').fetchall()
    conn.close()

    return render_template('dashboard.html', 
                           total_scans=total_scans,
                           safe_count=safe_count,
                           phishing_count=phishing_count,
                           url_scans=url_scans,
                           email_scans=email_scans,
                           recent_scans=recent_scans)

if __name__ == '__main__':
    if not os.path.exists('templates'):
        os.makedirs('templates')
    
    # Keep a single process so request logs show in this same terminal.
    app.run(port=5050, debug=True, use_reloader=False)

# DB Reset Trigger
